---
name: dependency-confusion
description: Elite dependency-confusion / package-substitution hunting skill for authorized bug bounty, pentests, and supply-chain audits. ALWAYS activate for dependency confusion, dependency substitution, namespace confusion, package shadowing, internal package hijack, unclaimed npm package, unclaimed crate, claimable package name, private package leaked publicly, "is this package on npm/crates.io", scoped package not reserved, @scope not claimed, .npmrc scope registry, package-lock resolved private registry, Cargo.toml registry confusion, Cargo.lock source, leaked package.json/yarn.lock/pnpm-lock, internal package names in JS bundle/webpack/sourcemap/HAR, "find dependency confusion on $target", "check these packages for confusion", supply-chain takeover via public registry, postinstall RCE via confused package, or ANY request to find/verify/exploit dependency-confusion across npm (Node) and cargo/crates (Rust). Drives the full kill chain — name harvest → source classification → public-registry claimability → scope-ownership check → severity → ownership-verified PoC → report. npm + cargo focused. Never squats names you don't own. Token-efficient.
---

# DEPENDENCY-CONFUSION — Package Substitution Hunter (npm + cargo/crates)

> Finds the one condition that matters: a package the build pulls **by name**
> that is **not claimed on the public registry** and **not pinned to a private/
> local source**. If an attacker can register that name publicly with a higher
> version, the next `npm install` / `cargo build` runs attacker code.
>
> Engine: `scripts/depconf.py` (stdlib-only, Python 3.7+). Two modes:
> **audit** a checkout, or **recon** claimable names out of public artifacts.

When invoked, do NOT preamble. Run Phase 1 and emit the surface snapshot.

---

## Rule 0 — Authorization & ethics (non-negotiable)

- Only test targets you are authorized to (in-scope bounty / pentest / CTF).
- **Never register a public name you do not own** to "prove" confusion against
  someone else's build. That is a live supply-chain attack on third parties.
- Prove it the safe way: ownership check + a benign, non-executing PoC package
  under a name the program **invited** you to claim, or a passive callback
  (DNS/HTTP from a `preinstall` you control on YOUR test install). See
  `references/manual-techniques.md`.

## Rule 1 — Kill list (instant reject — do not report)

- Package **exists** on the public registry → not confusion (that's just a public dep).
- Scoped `@org/pkg` where the **scope is reserved** by an org on npm → attacker
  can't publish under it. LOW/informational only.
- Dep pinned to `file:` / `link:` / `git+` / `path =` / tarball URL → explicit source, safe.
- Monorepo **workspace/local** package (in-repo `name`, `workspace:` protocol,
  Cargo workspace member) → resolved locally, not from a registry.
- "The name *looks* internal" with no registry check → not a finding. **Confirm 404 or kill.**
- Typosquatting / similar-name (`expres` vs `express`) → that's typosquatting, a
  different bug class. Confusion = the **exact** internal name is unclaimed.

## Rule 2 — What we hunt (valid classes)

| Class | Condition | Default severity |
|-------|-----------|------------------|
| **npm unscoped confusion** | bare name, unclaimed on npmjs, default registry not overridden | HIGH |
| **npm lockfile-proven internal** | name resolved from a private host in `package-lock.json` AND unclaimed publicly | HIGH |
| **npm unclaimed scope** | `@scope/pkg` where the **scope itself** is unclaimed on npm (attacker creates the org) | HIGH |
| **npm recon leak** | internal name scraped from a public JS bundle / `.map` / HAR, unclaimed publicly | HIGH (unscoped) / triage (scoped) |
| **cargo crates.io confusion** | bare crate (no `registry`/`path`/`git`), unclaimed on crates.io | HIGH |
| **cargo alt-registry ambiguity** | `registry = "alt"` dep whose name can also be shadowed on crates.io (rust-lang/cargo#9162) | LOW/REVIEW |
| **npm private-default** | unscoped unclaimed, but `.npmrc registry=` is private (proxy-dependent) | MEDIUM |

## Rule 3 — No hallucination

Every HIGH must be backed by an actual registry response (HTTP 404 from
`registry.npmjs.org/<name>` or `crates.io/api/v1/crates/<name>`). The engine
records it in `exists_public`. If the registry was unreachable → REVIEW, not HIGH.

---

## The pipeline (run in order)

### Phase 1 — Harvest candidate names
Two inputs, use whichever you have:
- **You have the code** (repo, leaked archive, `.git` dump, exposed `/package.json`):
  point the engine at the directory.
- **You only have the live target**: collect public JS, `*.js.map` sourcemaps
  (the `sources[]` array leaks `node_modules/<name>` and `webpack://@scope/pkg`),
  HTML, and a Burp/HAR export → feed to `--recon`. ~5% of assets leak claimable
  internal names this way.

### Phase 2 — Classify source & check claimability  (the engine does this)
```bash
# audit a checkout (npm + cargo, lockfile-aware)
python3 scripts/depconf.py /path/to/repo

# hunt from outside — scrape names from artifacts and test them
python3 scripts/depconf.py --recon bundle.js app.js.map index.html traffic.har --ecosystem npm

# one-off: is a single name claimable?
python3 scripts/depconf.py --name @acme/widgets --ecosystem npm
python3 scripts/depconf.py --name acme_internal_crate --ecosystem cargo

# JSON for chaining; --offline to classify without network
python3 scripts/depconf.py /path/to/repo --json
```
What it inspects: `package.json` (all dep fields) · `.npmrc` + `.yarnrc.yml`
(default + per-scope registry) · `package-lock.json`/`npm-shrinkwrap.json`
(resolved-host = proven-internal) · `Cargo.toml` (all dep tables, `registry`/
`path`/`git`/`workspace`, renamed `package=`) · `Cargo.lock` (`source =` →
crates.io vs alt vs local). Scoring model & false-positives: `references/triage.md`.

### Phase 3 — Verify ownership before any PoC
For each HIGH, confirm the name is genuinely **unowned** (not an npm security
holder placeholder, not a recently-unpublished name). See `references/manual-techniques.md`.

### Phase 4 — Safe PoC
Demonstrate resolvability/precedence without attacking third parties. Passive
callback from a `preinstall`/`build.rs` on **your own** authorized install, or a
program-blessed name. Capture install logs + callback proof.

### Phase 5 — Report
Impact-first: confusion → arbitrary code execution on dev/CI machines and
build artifacts (supply-chain RCE). Use `references/report-template.md`.

---

## Quick reference — is it confusable?

```dot
digraph d {
  rankdir=LR; node[shape=box,fontsize=10];
  "dep pulled by name" -> "explicit source?\n(file/link/git/path/tarball/workspace)" ;
  "explicit source?\n(file/link/git/path/tarball/workspace)" -> "SAFE" [label="yes"];
  "explicit source?\n(file/link/git/path/tarball/workspace)" -> "exists on public registry?" [label="no"];
  "exists on public registry?" -> "SAFE (public dep)" [label="yes"];
  "exists on public registry?" -> "scoped @org/pkg?" [label="no (404)"];
  "scoped @org/pkg?" -> "scope reserved on npm?" [label="yes"];
  "scope reserved on npm?" -> "LOW" [label="yes"];
  "scope reserved on npm?" -> "HIGH (claim org)" [label="no"];
  "scoped @org/pkg?" -> "HIGH (classic)" [label="no (unscoped)"];
}
```

## Common mistakes
- Trusting the name pattern instead of the 404. Always check the registry.
- Reporting a reserved-scope package as HIGH. Reserved scope = attacker can't publish.
- Forgetting build/dev deps and **transitive** internal names in lockfiles — those install too.
- Hammering crates.io: it asks for ~1 req/sec + a UA. The engine serializes crate checks.
- Treating an alt-registry-pinned crate as safe without checking crates.io shadowing.

## Defensive note (for fix recommendations in reports)
Reserve your org scope publicly; pin a per-scope private registry in `.npmrc`
(`@org:registry=`); use scoped names internally; for Cargo always specify
`registry =` (or `path`/`git`) and avoid bare internal crate names; commit
lockfiles; monitor public registries for your internal names.

## References
- `references/triage.md` — full risk model, severity matrix, false-positive killers
- `references/manual-techniques.md` — recon sources, ownership verification, safe PoC, defenses
- `references/report-template.md` — submission-ready template + impact language
- `scripts/depconf.py` — the detection/recon engine (`--help`)
